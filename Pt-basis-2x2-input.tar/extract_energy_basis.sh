for i in 1_4layer-DZV  1_4layer-TZV  1_4layer-TZVP monolayer-DZV  monolayer-TZV  monolayer-TZVP  surface-DZV  surface-TZV  surface-TZVP
do 
ene=`grep "ENERGY|" $i/log.out | tail -1| tail -1 | awk '{print $9}'`
echo $i $ene
done
eneh=`grep "ENERGY|" H2/log.out | tail -1 | awk '{print $9}'`
echo "Ene H2" $eneh
