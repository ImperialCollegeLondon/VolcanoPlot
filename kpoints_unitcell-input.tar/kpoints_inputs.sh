#!/bin/bash

kpoints="3 4 5 6 7 8 9 10 11 12 13 14 15"

basis_file=BASIS_SET
potential_file=GTH_POTENTIALS
template_file=template.inp
struct_file=Struct_in.xyz
input_file=cp2k.inp
output_file=log.out


echo "Running ..."
for ii in $kpoints ; do
    work_dir=kpoints_${ii}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -r $work_dir/*
    fi
    sed "s/.*MONKHORST-PACK.*/SCHEME MONKHORST-PACK ${ii} ${ii} 1/" \
        $template_file > $work_dir/$input_file
    #cp $basis_file $work_dir
    #cp $potential_file $work_dir
    echo "working on directory " $work_dir
    echo "input created"
    cp $struct_file $work_dir
    cp job.pbs $work_dir
    cd $work_dir
      if [ -f $output_file ] ; then
          rm $output_file
      fi
      qsub job.pbs > job_ID.dat
     echo "calculation submitted "
      sleep 1
    cd ..
done
echo "...done!"
