for i in 1_4layer-441  1_4layer-551  1_4layer-661 1_4layer-771 monolayer-441  monolayer-551  monolayer-661 monolayer-771 surface-441  surface-551  surface-661 surface-771
do 
ene=`grep "ENERGY| Total FORCE_EVAL ( QS ) energy (a.u.):" $i/log.out | tail -1| tail -1 | awk '{print $9}'`
echo $i $ene
done
eneh=`grep "ENERGY| Total FORCE_EVAL ( QS ) energy (a.u.)" H2/log.out | tail -1 | awk '{print $9}'`
echo "Ene H2" $eneh
