#!/bin/bash

#latt="4.10 4.12 4.14 4.16 4.18 4.20 4.22 4.24 4.26 4.28 4.30 4.32 4.34 4.36 4.38 4.40 4.42 4.44 4.46 4.48 4.50"
latt="2.80 2.85 2.90 2.95 3.00 3.05 3.10 3.15 3.20 3.25 3.30 3.35 3.40 3.45 3.50"

input_file=cp2k.inp
output_file=log.out
plot_file=lattice_data.ssv
number_of_atom=2.0
hatree_to_ev=27.2114

rel_cutoff=60

echo "# Grid kpoints vs total energy" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# PWD: $PWD" >> $plot_file
#echo "# REL_CUTOFF = $rel_cutoff" >> $plot_file
echo -n "# Lattice (A) | Total Energy per Cell (eV)" >> $plot_file
printf "\n" >> $plot_file
grid_header=false
for ii in $latt ; do
    work_dir=lattice_${ii}
    total_energy=$(grep -e '^[ \t]*Total energy' $work_dir/$output_file | awk '{print $3}')
    total_energy_per_cell=`echo "$total_energy * $hatree_to_ev" | bc -l`
#    ngrids=$(grep -e '^[ \t]*QS| Number of grid levels:' $work_dir/$output_file | \
#             awk '{print $6}')
#    if $grid_header ; then
#        for ((igrid=1; igrid <= $ngrids; igrid++)) ; do
#            printf " | NG on grid %d" $igrid >> $plot_file
#        done
#        grid_header=false
#    fi
    printf "%10.2f  %15.10f" $ii $total_energy_per_cell >> $plot_file
#    for ((igrid=1; igrid <= $ngrids; igrid++)) ; do
#        grid=$(grep -e '^[ \t]*count for grid' $work_dir/$output_file | \
#               awk -v igrid=$igrid '(NR == igrid){print $5}')
#        printf "  %6d" $grid >> $plot_file
#    done
    printf "\n" >> $plot_file
done
