#!/bin/bash

latt="2.80 2.85 2.90 2.95 3.00 3.05 3.10 3.15 3.20 3.25 3.30 3.35 3.40 3.45 3.50"

basis_file=BASIS_SET
potential_file=GTH_POTENTIALS
template_file=template.inp
input_file=cp2k.inp
output_file=log.out


for ii in $latt ; do
    work_dir=lattice_${ii}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -r $work_dir/*
    fi
    sed -e "s/LT_CELL/${ii} ${ii} ${ii}/g" \
        $template_file > $work_dir/$input_file
    #cp $basis_file $work_dir
    #cp $potential_file $work_dir
    cp job.pbs $work_dir
    cd $work_dir
      if [ -f $output_file ] ; then
          rm $output_file
      fi
      qsub job.pbs > job_ID.dat
      sleep 1
    cd ..
done
