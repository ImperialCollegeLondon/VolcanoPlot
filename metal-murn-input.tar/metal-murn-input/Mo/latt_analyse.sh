#!/bin/bash

latt="2.80 2.85 2.90 2.95 3.00 3.05 3.10 3.15 3.20 3.25 3.30 3.35 3.40 3.45 3.50"

input_file=cp2k.inp
output_file=log.out
plot_file=lattice_data.ssv
number_of_atom=2.0
hatree_to_ev=27.2114
hatree_to_ry=2.0
A_to_bohr=1.8897

rel_cutoff=60

echo "# Grid kpoints vs total energy" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# PWD: $PWD" >> $plot_file
#echo "# REL_CUTOFF = $rel_cutoff" >> $plot_file
echo -n "# Lattice (A) | Total Energy per Cell (eV)" >> $plot_file
printf "\n" >> $plot_file
grid_header=false
for ii in $latt ; do
    work_dir=lattice_${ii}
    total_energy=$(grep -e '^[ \t]*Total energy' $work_dir/$output_file | awk '{print $3}')
    total_energy_per_cell=`echo "$total_energy * $hatree_to_ev" | bc -l`
    printf "%10.2f  %15.10f" $ii $total_energy_per_cell >> $plot_file
    printf "\n" >> $plot_file
done

plot_file=MURN.inp
echo "1" > $plot_file
echo "1" >> $plot_file
echo "5.2 6.7 200"  >> $plot_file
echo "15" >> $plot_file
for ii in $latt ; do
    work_dir=lattice_${ii}
    total_energy=$(grep -e '^[ \t]*Total energy' $work_dir/$output_file | awk '{print $3}')
    total_energy_per_cell=`echo "$total_energy * $hatree_to_ry " | bc -l` 
    lattice=`echo "$ii*$A_to_bohr" | bc -l`
    printf "%5.2f  %15.10f" $lattice $total_energy_per_cell >> $plot_file
    printf "\n" >> $plot_file
done


