#!/bin/bash

latt="3.80 3.85 3.90 3.95 4.00 4.05 4.10 4.15 4.20 4.25 4.30 4.35 4.40 4.45 4.50"

basis_file=BASIS_SET
potential_file=GTH_POTENTIALS
template_file=template.inp
input_file=cp2k.inp
output_file=log.out


echo "Running ..."
for ii in $latt ; do
    work_dir=lattice_${ii}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -r $work_dir/*
    fi
    sed -e "s/LT_CELL/${ii} ${ii} ${ii}/g" \
        $template_file > $work_dir/$input_file
    #cp $basis_file $work_dir
    #cp $potential_file $work_dir
    cp job.pbs $work_dir
    echo "creating directory" $work_dir
    echo "submitting job in" $work_dir
    cd $work_dir
      if [ -f $output_file ] ; then
          rm $output_file
      fi
      qsub job.pbs > job_ID.dat
      sleep 1
    cd ..
done
echo "...done!"
