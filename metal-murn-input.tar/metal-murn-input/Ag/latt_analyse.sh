#!/bin/bash

latt="3.80 3.85 3.90 3.95 4.00 4.05 4.10 4.15 4.20 4.25 4.30 4.35 4.40 4.45 4.50"

input_file=cp2k.inp
output_file=log.out
plot_file=lattice_data.ssv
number_of_atom=2.0
hatree_to_ev=27.2114
hatree_to_ry=2.0
A_to_bohr=1.8897

rel_cutoff=60

echo "# Grid kpoints vs total energy" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# PWD: $PWD" >> $plot_file
#echo "# REL_CUTOFF = $rel_cutoff" >> $plot_file
echo -n "# Lattice (A) | Total Energy per Cell (eV)" >> $plot_file
printf "\n" >> $plot_file
grid_header=false
for ii in $latt ; do
    work_dir=lattice_${ii}
    total_energy=$(grep -e '^[ \t]*Total energy' $work_dir/$output_file | awk '{print $3}')
    total_energy_per_cell=`echo "$total_energy * $hatree_to_ev" | bc -l`
    printf "%10.2f  %15.10f" $ii $total_energy_per_cell >> $plot_file
    printf "\n" >> $plot_file
done

plot_file=MURN.inp
echo "1" > $plot_file
echo "1" >> $plot_file
echo "7.0 8.6 200"  >> $plot_file
echo "15" >> $plot_file
for ii in $latt ; do
    work_dir=lattice_${ii}
    total_energy=$(grep -e '^[ \t]*Total energy' $work_dir/$output_file | awk '{print $3}')
    total_energy_per_cell=`echo "$total_energy * $hatree_to_ry " | bc -l` 
    lattice=`echo "$ii*$A_to_bohr" | bc -l`
    printf "%5.2f  %15.10f" $lattice $total_energy_per_cell >> $plot_file
    printf "\n" >> $plot_file
done


